<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ItsolutionStuff.com</title>
</head>
<body style="font-family:Arial, vardana">
<p style="font-size:24px"><?php echo e($details['title']); ?></p>
<p style="font-size:18px; font-weight:bold;"><?php echo e($details['body']); ?></p>  
<p style="font-size:16px"><?php echo e($details['Token']); ?></p>
<br /> 
<br />
<p style="font-size:14px">Thank you</p>
</body>
</html><?php /**PATH C:\Users\rajesh veer\Desktop\ecom\laravel\resources\views/emails/myTestMail.blade.php ENDPATH**/ ?>